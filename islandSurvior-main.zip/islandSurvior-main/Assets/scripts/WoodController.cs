using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;
 
public class WoodController : MonoBehaviour
{
    public AudioSource src;
    public AudioClip chop;
    int LifePoint;
    int time;
    bool is_spring;

    void Start()
    {
        time = 5;
        LifePoint = 3;
        is_spring = false;
    }
    private void Update() {
    }

    private IEnumerator VisualIndicator(Color color)
    {
        GetComponent<SpriteRenderer>().color = color;
        yield return new WaitForSeconds(0.05f);
        GetComponent<SpriteRenderer>().color = Color.white;
    }

    void OnMouseDown(){
        if(Time.timeScale == 0)
            return;
        src.PlayOneShot(chop, 1f);
        time -= 1;
        StartCoroutine(VisualIndicator(Color.grey));
        if(time == 0){
            GameObject.Find("GameManager").GetComponent<GameManager>().addbapplescore(3);
            GameObject.Find("GameManager").GetComponent<GameManager>().addbwoodscore(7);
            if(GameObject.Find("EventManager").GetComponent<EventManager>().isSpring){
                GameObject.Find("GameManager").GetComponent<GameManager>().addbapplescore(3);
                GameObject.Find("GameManager").GetComponent<GameManager>().addbwoodscore(7);
            }
            LifePoint--;
            time = 5;
            
            if(LifePoint == 0)
                Destroy(gameObject);
        }
    }

    public void setSpring(bool tmp){
        is_spring = tmp;
    }
}
  