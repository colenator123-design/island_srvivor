using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CowController : MonoBehaviour
{
    public GameObject CowPerfab;
    private float time;
    // Start is called before the first frame update
    void Start()
    {
        time = 0;
        
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;
        if(time >= Random.Range(4.5f, 10.5f)){
            GameObject Cow = Instantiate(CowPerfab, transform.position, Quaternion.identity);
            time = 0;
        }
    }
}
