using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EventManager : MonoBehaviour
{
    public GameObject TimeManager, Canvas, Woods;
    public bool isSpring, isMad;
    
    Vector3 StartPos;
    Vector2 Speed = new Vector2(200f,100f);
    Vector2 Amp = new Vector2(2f,0.2f);
    float ShakingTime = 5f, CurrentTime;
    bool IsShaking = true;

    
    // Start is called before the first frame update
    void Start()
    {
        init();
        StartPos = GameObject.Find("Grid").transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (IsShaking)
            Shaking();
        else
            GameObject.Find("Grid").transform.position = StartPos;
    }

    void Earthquack(){
        IsShaking = true;
        if(GameObject.Find("FoodTower")){
            Destroy(GameObject.Find("FoodTower"));
            GameObject.Find("FoodTowerSpawner").GetComponent<TowerController>().setBuilt(false);
        }
        else if(GameObject.Find("WaterTower")){
            Destroy(GameObject.Find("WaterTower"));
            GameObject.Find("WaterTowerSpawner").GetComponent<TowerController>().setBuilt(false);
        }
        else{
            GameObject.Find("GameManager").GetComponent<GameManager>().addhrockscore(-50);
            GameObject.Find("GameManager").GetComponent<GameManager>().addhwoodscore(-50);
        }
        string tmp = "Earthquacked!\nbuildings are damaged";
        Canvas.GetComponent<UIManager>().SpecialEvent_show(tmp);
    }

    void Drought(){
        TimeManager.GetComponent<TimeManager>().setDrought(true);
        string tmp = "Drought!\nNeeded water is doubled!";
        Canvas.GetComponent<UIManager>().SpecialEvent_show(tmp);
    }

    void Spring(){
        isSpring = true;
        string tmp = "It's spring!\nTrees are dropping doubled resouces!";
        Canvas.GetComponent<UIManager>().SpecialEvent_show(tmp);
    }

    void MadCow(){
        isMad = true;
        string tmp = "Cows are mad!\nThey are moving faster!";
        Canvas.GetComponent<UIManager>().SpecialEvent_show(tmp);
    }

    void init(){
        isSpring = false;
        isMad = false;
        IsShaking = false;
        CurrentTime = 0;
    }

    void Shaking(){
        CurrentTime += Time.fixedDeltaTime;
        Vector3 pos = StartPos;
        pos.x += Amp.x * (Mathf.Sin(Time.time * Speed.x));
        pos.y += Amp.y * (Mathf.Sin(Time.time * Speed.y));
        GameObject.Find("Grid").transform.position = pos;
        if (CurrentTime >= ShakingTime){
            IsShaking = false;
            CurrentTime = 0;
        }
    }

    public void RandomEvent(){
        float result = Random.value;
        if(result < 0.2){
            Drought();
        }
        else if(result < 0.4){
            Spring();
        }
        else if(result < 0.7){
            MadCow();
        }
        else if(result < 0.9){
            Earthquack();
        }
        else{
            return;
        }
    }
}
