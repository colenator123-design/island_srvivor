using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class indicator : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(GameObject.Find("barrel")){
            GameObject barrel =GameObject.Find("barrel");
            Vector3 v = barrel.GetComponent<Transform>().position - transform.position;
            v.z = 0;
            Quaternion rotation = Quaternion.FromToRotation(Vector3.up, v);
            transform.rotation = rotation;
        }
        
    }
}
