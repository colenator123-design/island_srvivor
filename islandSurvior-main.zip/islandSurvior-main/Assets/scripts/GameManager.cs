using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Text = TMPro.TextMeshProUGUI;

public class GameManager : MonoBehaviour
{
    public Text bAppleText;
    public Text bWoodText;
    public Text bRockText;
    public Text bWaterText;
    public Text hAppleText;
    public Text hWoodText;
    public Text hRockText;
    public Text hWaterText;
    int bapplescore;
    int bwoodscore;
    int brockscore;
    int bwaterscore;
    int happlescore;
    int hwoodscore;
    int hrockscore;
    int hwaterscore;
    // Start is called before the first frame update
    void Start()
    {
        bapplescore = 0;
        bwoodscore = 0;
        brockscore = 0;
        bwaterscore = 0;
        happlescore = 0;
        hwoodscore = 0;
        hrockscore = 0;
        hwaterscore = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.Escape)){
            GameObject.Find("Canvas").GetComponent<UIManager>().Pause_show();
        }
        if(Input.GetKey(KeyCode.R))
            GameObject.Find("Canvas").GetComponent<UIManager>().Pause_hide();

        bAppleText.text = "" + bapplescore;
        bWoodText.text = "" + bwoodscore;
        bRockText.text = "" + brockscore;
        bWaterText.text = "" + bwaterscore;
        hAppleText.text = "" + happlescore;
        hWoodText.text = "" + hwoodscore;
        hRockText.text = "" + hrockscore;
        hWaterText.text = "" + hwaterscore;
    }
    public void addbapplescore(int n)
    {
        bapplescore += n;
    }
    public void addhapplescore(int n)
    {
        happlescore += n;
    }
    public void addbwoodscore(int n)
    {
        bwoodscore += n;
    }
    public void addhwoodscore(int n)
    {
        hwoodscore += n;
        if(hwoodscore < 0)
            hwoodscore = 0;
    }
    public void addbrockscore(int n)
    {
        brockscore += n;
    }
    public void addhrockscore(int n)
    {
        hrockscore += n;
        if(hrockscore < 0)
            hrockscore = 0;
    }
    public void addbwaterscore(int n)
    {
        bwaterscore += n;
    }
    public void addhwaterscore(int n)
    {
        hwaterscore += n;
    }

    public void damage()
    {
        bapplescore = 0;
        bwoodscore = 0;
        brockscore = 0;
        bwaterscore = 0;
    }
    public void putsource()
    {
        happlescore += bapplescore;
        hwoodscore += bwoodscore;
        hrockscore += brockscore;
        hwaterscore += bwaterscore;
        bapplescore = 0;
        bwoodscore = 0;
        brockscore = 0;
        bwaterscore = 0;
        
    }
    public bool can_survive(int food, int water){
        return (happlescore >= food) && (hwaterscore >= water);
    }

    public bool can_buildWT(){
        return (hrockscore >= 100) && (hwoodscore >= 100);
    }

    public bool can_buildFT(){
        return (hwoodscore >= 150);
    }
}
