using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RockController : MonoBehaviour
{
    public AudioSource src;
    public AudioClip hit;
    // Start is called before the first frame update
    int LifePoint;
    int time;
    // Start is called before the first frame update
    void Start()
    {
        time=10;
        LifePoint=3;
    }

    // Update is called once per frame
    void Update()
    {

    }
    void OnMouseDown(){
        if(Time.timeScale == 0)
            return;
        src.PlayOneShot(hit, 1f);
        time-=1;
        StartCoroutine(VisualIndicator(Color.grey));
        if(time==0){
            GameObject.Find("GameManager").GetComponent<GameManager>().addbrockscore(7);
            LifePoint-=1;
            time=10;
        }
        if(LifePoint==0)
            Destroy(gameObject);
    }
    private IEnumerator VisualIndicator(Color color)
    {
        GetComponent<SpriteRenderer>().color = color;
        yield return new WaitForSeconds(0.05f);
        GetComponent<SpriteRenderer>().color = Color.white;
    }
}
