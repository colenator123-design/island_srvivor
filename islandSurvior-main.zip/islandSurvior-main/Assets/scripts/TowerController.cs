using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TowerController : MonoBehaviour
{
    private Transform playerTransform;
    public GameObject towerPrefab, Canvas, GameManager, confirm, cancel;
    private bool is_built, is_inner;
    string type;
    // Start is called before the first frame update
    void Start()
    {
        is_built = false;
        is_inner = false;
        if(this.name == "FoodTowerSpawner")
            type = "FoodTower";
        if(this.name == "WaterTowerSpawner")
            type = "WaterTower";
    }

    // Update is called once per frame
    void Update(){
        if(is_built)
            return;
        if (is_inner && Input.GetKey("e")){
            string tmp = "";
            if(type == "FoodTower")
                tmp = "Spending \n150 woods\nto build a food tower?";
            else if(type == "WaterTower")
                tmp = "Spending\n100 woods and 100 stones\nto build a water tower?";
            Canvas.GetComponent<UIManager>().TowerPopUp_show(tmp);
        }
    }

    public void build(){
        if(!is_inner)
            return;
        if(this.name == "FoodTowerSpawner"){
            if(GameManager.GetComponent<GameManager>().can_buildFT()){ 
                GameObject Tower = Instantiate(towerPrefab, transform.position, Quaternion.identity);
                Tower.name = "FoodTower";
                is_built = true;
                GameManager.GetComponent<GameManager>().addhwoodscore(-150);
            }
        }
        else if(this.name == "WaterTowerSpawner"){
            if(GameManager.GetComponent<GameManager>().can_buildWT()){ //enough resource
                GameObject Tower = Instantiate(towerPrefab, transform.position, Quaternion.identity);
                Tower.name = "WaterTower";
                is_built = true;
                GameManager.GetComponent<GameManager>().addhwoodscore(-100);
                GameManager.GetComponent<GameManager>().addhrockscore(-100);
            }
        }
        Canvas.GetComponent<UIManager>().TowerPopUp_hide();
    }

    void OnTriggerEnter2D(Collider2D col){
        if(col.tag == "Player")
            is_inner = true;
    }

    void OnTriggerExit2D(Collider2D col){
        if(col.tag == "Player")
            is_inner = false;
    }

    public void setBuilt(bool tmp){
        is_built = tmp;
    }
    
}
