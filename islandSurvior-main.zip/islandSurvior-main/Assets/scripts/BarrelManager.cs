using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarrelManager : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject Buckets;
    bool flag;
    void Start()
    {
        flag = true;
    }

    // Update is called once per frame
    void Update()
    {
        if(!flag){
            Produce();
            flag = true;
        }
    }
    void Produce()
    {
        float x,y;
        x=Random.Range(-65,58);
        y=Random.Range(-56,38);
        GameObject tmp = Instantiate(Buckets, new Vector3(x,y,0), Quaternion.identity);
        tmp.name = "barrel";

    }

    public void setFlag(bool tmp){
        flag = tmp;
    }
}
