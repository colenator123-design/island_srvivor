using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Text = TMPro.TextMeshProUGUI;
using UnityEngine.SceneManagement;
public class TimeManager : MonoBehaviour
{
    public Text clock, day_end;
    public GameObject Canvas, GameManager;
    private bool isDrought;
    private float time;
    private int oclock, day;
    private int foodNeeded, waterNeeded;
    private float myfixedDtime;

    // Start is called before the first frame update
    void Start()
    {       
        myfixedDtime = Time.fixedDeltaTime;
        day = 0;
        oclock = 6;
        time = 0f;
        foodNeeded = 15;
        waterNeeded = 21;
        isDrought = false;
        clock.text = oclock + ":00";
        resume();
    }

    // Update is called once per frame
    void Update()
    {
        Time.fixedDeltaTime = myfixedDtime * Time.timeScale;
        time += Time.fixedDeltaTime;
        clock.text = oclock + ":00";
        if(time > 15f){
            oclock++;
            time = 0f;
        }
        if (oclock == 24)
            endDay();
    }
    public void pause()
    {
        Time.timeScale = 0;
    }
    public void resume()
    {
        Time.timeScale = 1;
    }
    void endDay(){
        GameObject.Find("Player").GetComponent<PlayerController>().goHome();
        if(GameObject.Find("WaterTower"))
            GameManager.GetComponent<GameManager>().addhwaterscore(50);
        if(GameObject.Find("FoodTower"))
            GameManager.GetComponent<GameManager>().addhapplescore(50);
        needsUpdate();
        day_end.text = "Day " + day + " ends...";
        if(isDrought){
            day_end.text += "you need\n" + foodNeeded + " food / " + waterNeeded * 2 + " water\nto live on...\n";
            GameManager.GetComponent<GameManager>().addhwaterscore(-waterNeeded);
        }   
        else
            day_end.text += "you need\n" + foodNeeded + " food / " + waterNeeded + " water\nto live on...\n";
        Canvas.GetComponent<UIManager>().CountPage_show();
        if(GameManager.GetComponent<GameManager>().can_survive(foodNeeded, waterNeeded)){
            GameManager.GetComponent<GameManager>().addhapplescore(-foodNeeded);
            GameManager.GetComponent<GameManager>().addhwaterscore(-waterNeeded);
            day_end.text += "\n\n\nyou survived.";
        }
        else{
            day_end.text += "\n\n\n.";
            Canvas.GetComponent<UIManager>().DiedMes_show();
            resume();   
            StartCoroutine(wait());
        }
        oclock = 6;
        day++;
        if(day == 20)
            SceneManager.LoadScene(3);
        isDrought = false;
    }

    void needsUpdate(){
        if(day == 1)
            return;
        if(day % 5 == 1){
            foodNeeded *= 2;
            waterNeeded *= 2;
        }
    }

    public void setDrought(bool tmp)
    {
        isDrought = tmp;
    }

    IEnumerator wait(){
        yield return new WaitForSecondsRealtime(1.5f);
        SceneManager.LoadScene(2);
    }

}
