using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterController : MonoBehaviour
{
    public AudioSource src;
    public AudioClip hit;
    int time;
    // Start is called before the first frame update
    void Start()
    {
        time=5;
    }

    // Update is called once per frame
    void Update()
    {
    }
    void OnMouseDown(){
        if(Time.timeScale == 0)
            return;
        if(GameObject.Find("Player").GetComponent<PlayerController>().getBucket() < 7)
            return;
        time -= 1;
        src.PlayOneShot(hit, 1f);
        StartCoroutine(VisualIndicator(Color.grey));
        if(time == 0){
            GameObject.Find("GameManager").GetComponent<GameManager>().addbwaterscore(7);
            GameObject.Find("Player").GetComponent<PlayerController>().addBucket(-7);
            time = 5;
        }
    }
    private IEnumerator VisualIndicator(Color color)
    {
        GetComponent<SpriteRenderer>().color = color;
        yield return new WaitForSeconds(0.05f);
        GetComponent<SpriteRenderer>().color = Color.white;
    }
}
