using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Text = TMPro.TextMeshProUGUI;

public class UIManager : MonoBehaviour
{
    public GameObject TowerPopUp, CountPage, EventPage, DiedMsg, Pause;
    public Text EventText, TowerPopUpText;
    // Start is called before the first frame update
    void Start()
    {
        TowerPopUp_hide();
        CountPage_hide();
        SpecialEvent_hide();
        DiedMes_hide();
        Pause_hide();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    
    public void TowerPopUp_show(string content){
        GameObject.Find("TimeManager").GetComponent<TimeManager>().pause();
        TowerPopUpText.text = content;
        TowerPopUp.SetActive(true);
    }
    public void TowerPopUp_hide(){        
        GameObject.Find("TimeManager").GetComponent<TimeManager>().resume();
        TowerPopUp.SetActive(false);
    }
    public void CountPage_show(){
        GameObject.Find("TimeManager").GetComponent<TimeManager>().pause();
        CountPage.SetActive(true);
    }
    public void  CountPage_hide(){
        GameObject.Find("TimeManager").GetComponent<TimeManager>().resume();
        CountPage.SetActive(false);
    }
    public void SpecialEvent_show(string content){
        EventText.text = content;
        EventPage.SetActive(true);
    }
    public void SpecialEvent_hide(){
        EventPage.SetActive(false);
    }
    public void DiedMes_show(){
        DiedMsg.SetActive(true);
    }
    public void DiedMes_hide(){
        DiedMsg.SetActive(false);
    }
    public void Pause_show(){        
        GameObject.Find("TimeManager").GetComponent<TimeManager>().pause();
        Pause.SetActive(true);
    }
    public void Pause_hide(){
        GameObject.Find("TimeManager").GetComponent<TimeManager>().resume();
        Pause.SetActive(false);
    }
}

