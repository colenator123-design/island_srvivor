using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class primitiveController1 : MonoBehaviour
{
    // Start is called before the first frame update
    GameObject player;
    float moveSpeed = 1.2f, delta = 0f;
    void Start()
    {   
        if(GameObject.Find("EventManager").GetComponent<EventManager>().isMad)
            moveSpeed = 1.7f;
        player = GameObject.FindWithTag("Player");
        
    }

    // Update is called once per frame
    void Update()
    {   
        if(delta > 0){
            delta -= 0.003f;
            if(delta < 0f)
                delta = 0;
        }
        Vector3 toward = this.transform.localScale;
        if(player.transform.position.x > this.transform.position.x)
            toward.x = -Mathf.Abs(toward.x);
        else
            toward.x = Mathf.Abs(toward.x);

        this.transform.localScale = toward;
        this.transform.position = Vector3.MoveTowards(this.transform.position,player.transform.position,(moveSpeed - delta) * Time.fixedDeltaTime);
    }
    
    void OnTriggerEnter2D(Collider2D col)
    {
        if(col.tag == "Player"){
            GameObject.Find("GameManager").GetComponent<GameManager>().damage();
            Destroy(gameObject);
        }
    }
    
    void OnMouseDown()
    {
        delta += 0.5f;
        StartCoroutine(VisualIndicator(Color.gray));
    }

    private IEnumerator VisualIndicator(Color color)
    {
        GetComponent<SpriteRenderer>().color = color;
        yield return new WaitForSeconds(0.05f);
        GetComponent<SpriteRenderer>().color = Color.white;
    }
}
